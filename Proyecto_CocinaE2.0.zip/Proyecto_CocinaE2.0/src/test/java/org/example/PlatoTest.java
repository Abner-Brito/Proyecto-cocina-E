package org.example;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class PlatoTest {

    @Test
    public void testGetNombre() {
        Plato plato = new Plato("Tacos", "Tacos de carne asada", 5.99);
        assertEquals("Tacos", plato.getNombre());
    }

    @Test
    public void testGetDescripcion() {
        Plato plato = new Plato("Tacos", "Tacos de carne asada", 5.99);
        assertEquals("Tacos de carne asada", plato.getDescripcion());
    }

    @Test
    public void testGetPrecio() {
        Plato plato = new Plato("Tacos", "Tacos de carne asada", 5.99);
        assertEquals(5.99, plato.getPrecio(), 0.01);
    }
}
