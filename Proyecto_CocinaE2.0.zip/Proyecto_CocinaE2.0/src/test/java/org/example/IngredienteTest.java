package org.example;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import org.junit.Test;

public class IngredienteTest {

    @Test
    public void testGetNombre() {
        Ingrediente ingrediente = new Ingrediente("Tomate", 100);
        assertEquals("Tomate", ingrediente.getNombre());
    }

    @Test
    public void testGetCantidadDisponible() {
        Ingrediente ingrediente = new Ingrediente("Tomate", 100);
        assertEquals(100, ingrediente.getCantidadDisponible());
    }

    @Test
    public void testReducirCantidad() {
        Ingrediente ingrediente = new Ingrediente("Tomate", 100);
        ingrediente.reducirCantidad(20);
        assertEquals(80, ingrediente.getCantidadDisponible());
    }

    @Test
    public void testReducirCantidadInvalida() {
        Ingrediente ingrediente = new Ingrediente("Tomate", 100);
        assertThrows(IllegalArgumentException.class, () -> {
            ingrediente.reducirCantidad(120);
        });
    }
}
