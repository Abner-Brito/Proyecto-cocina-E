package org.example;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import java.util.Arrays;

public class PedidoTest {

    @Test
    public void testGetTotal() {
        Plato plato1 = new Plato("Tacos", "Tacos de carne asada", 5.99);
        Plato plato2 = new Plato("Enchiladas", "Enchiladas de pollo", 6.99);
        Cliente cliente = new Cliente("Juan Perez", "juan.perez@example.com");
        Pedido pedido = new Pedido(Arrays.asList(plato1, plato2), cliente);
        assertEquals(12.98, pedido.getTotal(), 0.01);
    }

    @Test
    public void testGetCliente() {
        Cliente cliente = new Cliente("Juan Perez", "juan.perez@example.com");
        Plato plato1 = new Plato("Tacos", "Tacos de carne asada", 5.99);
        Plato plato2 = new Plato("Enchiladas", "Enchiladas de pollo", 6.99);
        Pedido pedido = new Pedido(Arrays.asList(plato1, plato2), cliente);
        assertEquals(cliente, pedido.getCliente());
    }

    @Test
    public void testGetPlatos() {
        Plato plato1 = new Plato("Tacos", "Tacos de carne asada", 5.99);
        Plato plato2 = new Plato("Enchiladas", "Enchiladas de pollo", 6.99);
        Cliente cliente = new Cliente("Juan Perez", "juan.perez@example.com");
        Pedido pedido = new Pedido(Arrays.asList(plato1, plato2), cliente);
        assertEquals(Arrays.asList(plato1, plato2), pedido.getPlatos());
    }
}
