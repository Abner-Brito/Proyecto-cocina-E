package org.example;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import org.junit.Test;
import java.util.Arrays;
import java.util.Date;

public class PedidoControllerTest {

    @Test
    public void testRegistrarPedido() {
        PedidoController pedidoController = new PedidoController();

        Plato plato1 = new Plato("Tacos", "Tacos de carne asada", 5.99);
        Plato plato2 = new Plato("Enchiladas", "Enchiladas de pollo", 6.99);
        Cliente cliente = new Cliente("Juan Perez", "juan.perez@example.com");
        Pedido pedido = new Pedido(Arrays.asList(plato1, plato2), cliente);

        pedidoController.registrarPedido(pedido);

        assertEquals(1, pedidoController.getPedidos().size());
        assertEquals(pedido, pedidoController.getPedidos().get(0));
    }

    @Test
    public void testBuscarPedidosPorFecha() {
        PedidoController pedidoController = new PedidoController();

        Plato plato1 = new Plato("Tacos", "Tacos de carne asada", 5.99);
        Plato plato2 = new Plato("Enchiladas", "Enchiladas de pollo", 6.99);
        Cliente cliente = new Cliente("Juan Perez", "juan.perez@example.com");
        Pedido pedido = new Pedido(Arrays.asList(plato1, plato2), cliente);

        Date hoy = new Date();
        pedidoController.registrarPedido(pedido);

        assertNotNull(pedidoController.buscarPedidosPorFecha(hoy));
    }
}
