package org.example;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class ClienteTest {

    @Test
    public void testGetNombre() {
        Cliente cliente = new Cliente("Juan Perez", "juan.perez@example.com");
        assertEquals("Juan Perez", cliente.getNombre());
    }

    @Test
    public void testGetContacto() {
        Cliente cliente = new Cliente("Juan Perez", "juan.perez@example.com");
        assertEquals("juan.perez@example.com", cliente.getContacto());
    }
}
