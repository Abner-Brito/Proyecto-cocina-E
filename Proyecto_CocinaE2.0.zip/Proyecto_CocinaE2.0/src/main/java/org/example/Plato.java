package org.example;

/**
 * Clase que representa un plato en el menú.
 */
public class Plato {
    private String nombre;
    private String descripcion;
    private double precio;

    /**
     * Constructor de la clase Plato.
     * @param nombre Nombre del plato.
     * @param descripcion Descripción del plato.
     * @param precio Precio del plato.
     */
    public Plato(String nombre, String descripcion, double precio) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
    }

    /**
     * Obtiene el nombre del plato.
     * @return Nombre del plato.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Obtiene la descripción del plato.
     * @return Descripción del plato.
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * Obtiene el precio del plato.
     * @return Precio del plato.
     */
    public double getPrecio() {
        return precio;
    }
}
