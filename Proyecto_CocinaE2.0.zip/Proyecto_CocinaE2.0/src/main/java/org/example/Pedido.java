package org.example;

import java.util.List;

/**
 * Clase que representa un pedido realizado por un cliente.
 */
public class Pedido {
    private List<Plato> platos;
    private Cliente cliente;
    private double total;

    /**
     * Constructor de la clase Pedido.
     * @param platos Lista de platos en el pedido.
     * @param cliente Cliente que realiza el pedido.
     */
    public Pedido(List<Plato> platos, Cliente cliente) {
        this.platos = platos;
        this.cliente = cliente;
        calcularTotal();
    }

    /**
     * Calcula el total del pedido sumando los precios de los platos.
     */
    private void calcularTotal() {
        total = platos.stream().mapToDouble(Plato::getPrecio).sum();
    }

    /**
     * Obtiene la lista de platos del pedido.
     * @return Lista de platos del pedido.
     */
    public List<Plato> getPlatos() {
        return platos;
    }

    /**
     * Obtiene el cliente que realiza el pedido.
     * @return Cliente que realiza el pedido.
     */
    public Cliente getCliente() {
        return cliente;
    }

    /**
     * Obtiene el total del pedido.
     * @return Total del pedido.
     */
    public double getTotal() {
        return total;
    }
}
