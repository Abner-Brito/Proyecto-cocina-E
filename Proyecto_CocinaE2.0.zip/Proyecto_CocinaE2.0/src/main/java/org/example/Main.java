package org.example;

import java.util.Arrays;
import java.util.Date;

public class Main {
    public static void main(String[] args) {
        // Crear algunos platos
        Plato plato1 = new Plato("Tacos", "Tacos de carne asada", 5.99);
        Plato plato2 = new Plato("Enchiladas", "Enchiladas de pollo", 6.99);

        // Crear un cliente
        Cliente cliente = new Cliente("Juan Perez", "juan.perez@example.com");

        // Crear un pedido
        Pedido pedido = new Pedido(Arrays.asList(plato1, plato2), cliente);

        // Crear una instancia del controlador de pedidos
        PedidoController pedidoController = new PedidoController();

        // Registrar el pedido
        pedidoController.registrarPedido(pedido);

        // Buscar pedidos por fecha (esto es solo un ejemplo; necesitarías ajustar esto para trabajar con fechas reales)
        Date hoy = new Date();
        System.out.println("Pedidos de hoy: " + pedidoController.buscarPedidosPorFecha(hoy));
    }
}
