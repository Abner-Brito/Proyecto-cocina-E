package org.example;

import java.util.List;
import java.util.ArrayList;
import java.util.Date;

/**
 * Controlador para la gestión de pedidos.
 */
public class PedidoController {

    private List<Pedido> pedidos;

    /**
     * Constructor de la clase PedidoController.
     */
    public PedidoController() {
        this.pedidos = new ArrayList<>();
    }

    /**
     * Registra un nuevo pedido en el sistema.
     * @param pedido Pedido a registrar.
     */
    public void registrarPedido(Pedido pedido) {
        try {
            if (pedido == null) {
                throw new Exception("El pedido no puede ser nulo");
            }
            pedidos.add(pedido);
            System.out.println("Pedido registrado correctamente");
        } catch (Exception e) {
            System.err.println("Error al registrar el pedido: " + e.getMessage());
        } finally {
            System.out.println("Finalizando el proceso de registro de pedido.");
        }
    }

    /**
     * Busca pedidos por fecha.
     * @param fecha Fecha de los pedidos a buscar.
     * @return Lista de pedidos en la fecha especificada.
     */
    public List<Pedido> buscarPedidosPorFecha(Date fecha) {
        List<Pedido> resultado = new ArrayList<>();
        for (Pedido pedido : pedidos) {
            // Supongamos que tienes un método getFecha() en Pedido para obtener la fecha del pedido
            // if (pedido.getFecha().equals(fecha)) {
            //     resultado.add(pedido);
            // }
        }
        return resultado;
    }

    /**
     * Obtiene la lista de todos los pedidos registrados.
     * @return Lista de pedidos.
     */
    public List<Pedido> getPedidos() {
        return pedidos;
    }
}
