package org.example;

/**
 * Clase que representa un cliente en el sistema.
 */
public class Cliente {
    private String nombre;
    private String contacto;

    /**
     * Constructor de la clase Cliente.
     * @param nombre Nombre del cliente.
     * @param contacto Información de contacto del cliente.
     */
    public Cliente(String nombre, String contacto) {
        this.nombre = nombre;
        this.contacto = contacto;
    }

    /**
     * Obtiene el nombre del cliente.
     * @return Nombre del cliente.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Obtiene la información de contacto del cliente.
     * @return Información de contacto del cliente.
     */
    public String getContacto() {
        return contacto;
    }
}
