package org.example;

/**
 * Clase que representa un ingrediente en el inventario.
 */
public class Ingrediente {
    private String nombre;
    private int cantidadDisponible;

    /**
     * Constructor de la clase Ingrediente.
     * @param nombre Nombre del ingrediente.
     * @param cantidadDisponible Cantidad disponible del ingrediente.
     */
    public Ingrediente(String nombre, int cantidadDisponible) {
        this.nombre = nombre;
        this.cantidadDisponible = cantidadDisponible;
    }

    /**
     * Obtiene el nombre del ingrediente.
     * @return Nombre del ingrediente.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Obtiene la cantidad disponible del ingrediente.
     * @return Cantidad disponible del ingrediente.
     */
    public int getCantidadDisponible() {
        return cantidadDisponible;
    }

    /**
     * Reduce la cantidad disponible del ingrediente.
     * @param cantidad Cantidad a reducir.
     */
    public void reducirCantidad(int cantidad) {
        if (cantidad <= cantidadDisponible) {
            cantidadDisponible -= cantidad;
        } else {
            throw new IllegalArgumentException("Cantidad a reducir mayor que la disponible");
        }
    }
}
