package org.example;

import java.util.Date;

/**
 * Clase que representa una venta realizada.
 */
public class Venta {
    private Pedido pedido;
    private Date fecha;
    private double total;

    /**
     * Constructor de la clase Venta.
     * @param pedido Pedido asociado a la venta.
     * @param fecha Fecha de la venta.
     */
    public Venta(Pedido pedido, Date fecha) {
        this.pedido = pedido;
        this.fecha = fecha;
        this.total = pedido.getTotal();
    }

    /**
     * Obtiene el pedido asociado a la venta.
     * @return Pedido asociado a la venta.
     */
    public Pedido getPedido() {
        return pedido;
    }

    /**
     * Obtiene la fecha de la venta.
     * @return Fecha de la venta.
     */
    public Date getFecha() {
        return fecha;
    }

    /**
     * Obtiene el total de la venta.
     * @return Total de la venta.
     */
    public double getTotal() {
        return total;
    }
}
