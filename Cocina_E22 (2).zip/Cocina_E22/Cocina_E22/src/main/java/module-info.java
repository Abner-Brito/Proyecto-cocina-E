module org.example.cocina_e22 {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;

    opens org.example.cocina_e22 to javafx.fxml;
    exports org.example.cocina_e22;
}