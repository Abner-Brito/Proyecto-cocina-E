package org.example.cocina_e22;

public class Cliente {
    private String nombre;
    private String contacto;
    private String preferencias;

    public Cliente(String nombre, String contacto, String preferencias) {
        this.nombre = nombre;
        this.contacto = contacto;
        this.preferencias = preferencias;
    }

    public String getNombre() {
        return nombre;
    }

    public String getContacto() {
        return contacto;
    }

    public String getPreferencias() {
        return preferencias;
    }

    @Override
    public String toString() {
        return nombre + "|" + contacto + "|" + preferencias;
    }

    public static Cliente fromString(String str) {
        String[] parts = str.split("\\|");
        return new Cliente(parts[0], parts[1], parts[2]);
    }
}