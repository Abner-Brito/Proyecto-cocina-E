package org.example.cocina_e22;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class RegistroPedidos {
    private List<Plato> platos;
    private List<Ingrediente> ingredientes;
    private ObservableList<String> pedidosObservableList = FXCollections.observableArrayList();
    private double totalPrecio = 0.0;
    private Label labelTotalPrecio = new Label("Total: $0.0");
    private static final String FILE_PATH = "pedidos.txt";
    private RegistroVentas registroVentas;

    public RegistroPedidos(List<Plato> platos, List<Ingrediente> ingredientes, RegistroVentas registroVentas) {
        this.platos = platos;
        this.ingredientes = ingredientes;
        this.registroVentas = registroVentas;
        cargarPedidos();
    }

    public void mostrar(Stage stage) {
        VBox vbox = new VBox();
        Label label = new Label("Registro de Pedidos");
        ListView<String> listView = new ListView<>(pedidosObservableList);
        Button btnAdd = new Button("Añadir Pedido");
        Button btnDelete = new Button("Eliminar Pedido");
        Button btnSave = new Button("Guardar Pedido y Generar Recibo");
        btnAdd.setOnAction(e -> anadirPedido());
        btnDelete.setOnAction(e -> eliminarPedido(listView.getSelectionModel().getSelectedItem()));
        btnSave.setOnAction(e -> guardarPedidoYGenerarRecibo());

        vbox.getChildren().addAll(label, listView, btnAdd, btnDelete, btnSave, labelTotalPrecio);

        Scene scene = new Scene(vbox, 400, 300);
        stage.setScene(scene);
        stage.setTitle("Registro de Pedidos");
        stage.show();
    }

    private void anadirPedido() {
        Stage addStage = new Stage();
        VBox vbox = new VBox();
        Label label = new Label("Añadir Pedido");
        ComboBox<String> comboBox = new ComboBox<>();
        for (Plato plato : platos) {
            comboBox.getItems().add(plato.getNombre());
        }
        TextField cantidadField = new TextField();
        cantidadField.setPromptText("Cantidad");
        Button btnSave = new Button("Guardar");
        btnSave.setOnAction(e -> {
            String nombrePlato = comboBox.getValue();
            int cantidad = Integer.parseInt(cantidadField.getText());
            if (nombrePlato != null && !nombrePlato.isEmpty() && cantidad > 0) {
                actualizarTotalPrecio(nombrePlato, cantidad);
                addStage.close();
            }
        });

        vbox.getChildren().addAll(label, comboBox, cantidadField, btnSave);
        Scene scene = new Scene(vbox, 300, 200);
        addStage.setScene(scene);
        addStage.setTitle("Añadir Pedido");
        addStage.show();
    }

    private void actualizarTotalPrecio(String nombrePlato, int cantidad) {
        for (Plato plato : platos) {
            if (plato.getNombre().equals(nombrePlato)) {
                double precioTotalPlato = plato.getPrecio() * cantidad;
                totalPrecio += precioTotalPlato;
                labelTotalPrecio.setText("Total: $" + totalPrecio);
                pedidosObservableList.add(nombrePlato + " x" + cantidad + " - $" + precioTotalPlato);
                break;
            }
        }
    }

    private void eliminarPedido(String pedido) {
        if (pedido != null) {
            pedidosObservableList.remove(pedido);
            // Update total price
            String[] parts = pedido.split(" - \\$");
            double precio = Double.parseDouble(parts[1]);
            totalPrecio -= precio;
            labelTotalPrecio.setText("Total: $" + totalPrecio);
        }
    }

    private void guardarPedidos() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (String pedido : pedidosObservableList) {
                writer.write(pedido);
                writer.newLine();
            }
            System.out.println("Pedidos guardados correctamente.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void cargarPedidos() {
        File file = new File(FILE_PATH);
        if (file.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    pedidosObservableList.add(line);
                    // Recalculate total price
                    String[] parts = line.split(" - \\$");
                    double precio = Double.parseDouble(parts[1]);
                    totalPrecio += precio;
                }
                labelTotalPrecio.setText("Total: $" + totalPrecio);
                System.out.println("Pedidos cargados correctamente.");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void guardarPedidoYGenerarRecibo() {
        guardarPedidos();
        // Generate receipt logic here
        System.out.println("Recibo generado y pedido guardado.");
        // Register the sale in RegistroVentas
        Venta venta = new Venta(LocalDate.now(), obtenerPlatosVendidos(), totalPrecio);
        registroVentas.registrarVenta(venta);
    }

    private List<Plato> obtenerPlatosVendidos() {
        // Logic to convert pedidosObservableList to List<Plato>
        // This is a placeholder implementation
        return new ArrayList<>(platos);
    }
}