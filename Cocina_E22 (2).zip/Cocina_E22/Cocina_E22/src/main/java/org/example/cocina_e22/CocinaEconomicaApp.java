package org.example.cocina_e22;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;

/**
 * Clase principal de la aplicación para el sistema de gestión de Cocina Económica.
 */
public class CocinaEconomicaApp extends Application {
    private List<Plato> platos;
    private List<Ingrediente> ingredientes;

    /**
     * Inicia la aplicación JavaFX.
     *
     * @param primaryStage el escenario principal para esta aplicación
     */
    @Override
    public void start(Stage primaryStage) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/org/example/cocina_e22/entrar-view.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            primaryStage.setScene(scene);
            primaryStage.setTitle("Sistema de Gestión de Cocina Económica");

            EntrarController controller = fxmlLoader.getController();
            controller.setApp(this);

            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Muestra el menú principal de la aplicación.
     *
     * @param primaryStage el escenario principal para esta aplicación
     */
    public void showMainMenu(Stage primaryStage) {
        primaryStage.setTitle("Sistema de Gestión de Cocina Económica");

        // Inicializa los platos e ingredientes predefinidos
        GestionIngredientes gestionIngredientes = new GestionIngredientes();
        ingredientes = gestionIngredientes.getIngredientes();
        GestionMenu gestionMenu = new GestionMenu(ingredientes);
        platos = gestionMenu.getPlatos();

        // Crea una instancia de RegistroVentas
        RegistroVentas registroVentas = new RegistroVentasImpl();

        // Crea botones para cada funcionalidad
        Button btnMenu = new Button("Gestión de Menú");
        btnMenu.setOnAction(e -> gestionMenu.mostrar(new Stage()));

        Button btnPedidos = new Button("Registro de Pedidos");
        btnPedidos.setOnAction(e -> new RegistroPedidos(platos, ingredientes, registroVentas).mostrar(new Stage()));

        Button btnInventario = new Button("Gestión de Ingredientes y Stock");
        btnInventario.setOnAction(e -> gestionIngredientes.mostrar(new Stage()));

        Button btnVentas = new Button("Registro de Ventas");
        btnVentas.setOnAction(e -> registroVentas.mostrar(new Stage()));

        Button btnClientes = new Button("Gestión de Clientes");
        btnClientes.setOnAction(e -> new GestionClientes().mostrar(new Stage()));

        Button btnPagos = new Button("Gestión de Pagos");
        btnPagos.setOnAction(e -> new GestionPagos(platos, ingredientes, registroVentas).mostrar(new Stage()));

        Button btnReportes = new Button("Generación de Reportes");
        btnReportes.setOnAction(e -> new GeneracionReportes(registroVentas).mostrar(new Stage()));

        // Diseño principal
        VBox vBox = new VBox(btnMenu, btnPedidos, btnInventario, btnVentas, btnClientes, btnPagos, btnReportes);
        Scene scene = new Scene(vBox, 400, 300);

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * Método principal para lanzar la aplicación.
     *
     * @param args los argumentos de la línea de comandos
     */
    public static void main(String[] args) {
        launch(args);
    }
}
