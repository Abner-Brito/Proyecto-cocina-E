package org.example.cocina_e22;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.temporal.WeekFields;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

public class GeneracionReportes {
    private RegistroVentas registroVentas;

    public GeneracionReportes(RegistroVentas registroVentas) {
        this.registroVentas = registroVentas;
    }

    public void mostrar(Stage stage) {
        VBox vbox = new VBox();
        TextArea textArea = new TextArea();
        textArea.setEditable(false);

        Button btnDailyReport = new Button("Generar Informe Diario");
        Button btnWeeklyReport = new Button("Generar Informe Semanal");
        Button btnMonthlyReport = new Button("Generar Informe Mensual");
        Button btnPopularityReport = new Button("Generar Informe de Popularidad de Platos");

        btnDailyReport.setOnAction(e -> textArea.setText(generarInformeDiario()));
        btnWeeklyReport.setOnAction(e -> textArea.setText(generarInformeSemanal()));
        btnMonthlyReport.setOnAction(e -> textArea.setText(generarInformeMensual()));
        btnPopularityReport.setOnAction(e -> textArea.setText(generarInformePopularidad()));

        vbox.getChildren().addAll(btnDailyReport, btnWeeklyReport, btnMonthlyReport, btnPopularityReport, textArea);

        Scene scene = new Scene(vbox, 600, 400);
        stage.setScene(scene);
        stage.setTitle("Generación de Reportes");
        stage.show();
    }

    private String generarInformeDiario() {
        LocalDate today = LocalDate.now();
        List<Venta> ventasDiarias = registroVentas.getVentas().stream()
                .filter(venta -> venta.getFecha().isEqual(today))
                .collect(Collectors.toList());
        return generarInforme(ventasDiarias, "Informe Diario");
    }

    private String generarInformeSemanal() {
        LocalDate today = LocalDate.now();
        WeekFields weekFields = WeekFields.of(Locale.getDefault());
        int currentWeek = today.get(weekFields.weekOfWeekBasedYear());
        List<Venta> ventasSemanales = registroVentas.getVentas().stream()
                .filter(venta -> venta.getFecha().get(weekFields.weekOfWeekBasedYear()) == currentWeek)
                .collect(Collectors.toList());
        return generarInforme(ventasSemanales, "Informe Semanal");
    }

    private String generarInformeMensual() {
        LocalDate today = LocalDate.now();
        int currentMonth = today.getMonthValue();
        List<Venta> ventasMensuales = registroVentas.getVentas().stream()
                .filter(venta -> venta.getFecha().getMonthValue() == currentMonth)
                .collect(Collectors.toList());
        return generarInforme(ventasMensuales, "Informe Mensual");
    }

    private String generarInformePopularidad() {
        Map<Plato, Long> popularidadPlatos = registroVentas.getVentas().stream()
                .flatMap(venta -> venta.getPlatos().stream())
                .collect(Collectors.groupingBy(plato -> plato, Collectors.counting()));
        return generarInformePopularidad(popularidadPlatos);
    }

    private String generarInforme(List<Venta> ventas, String titulo) {
        StringBuilder informe = new StringBuilder(titulo + "\n");
        informe.append("Fecha: ").append(LocalDate.now()).append("\n\n");
        double totalGanancias = 0.0;
        for (Venta venta : ventas) {
            informe.append(venta.toString()).append("\n");
            totalGanancias += venta.getTotal();
        }
        informe.append("\nTotal de Ventas: ").append(ventas.size()).append("\n");
        informe.append("Total de Ganancias: $").append(totalGanancias).append("\n");
        return informe.toString();
    }

    private String generarInformePopularidad(Map<Plato, Long> popularidadPlatos) {
        StringBuilder informe = new StringBuilder("Informe de Popularidad de Platos\n");
        informe.append("Fecha: ").append(LocalDate.now()).append("\n\n");
        for (Map.Entry<Plato, Long> entry : popularidadPlatos.entrySet()) {
            informe.append(entry.getKey().getNombre()).append(": ").append(entry.getValue()).append(" ventas\n");
        }
        return informe.toString();
    }
}