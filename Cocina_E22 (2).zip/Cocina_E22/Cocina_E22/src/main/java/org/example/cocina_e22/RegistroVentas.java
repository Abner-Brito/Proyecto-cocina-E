package org.example.cocina_e22;

import javafx.stage.Stage;
import java.util.List;

public interface RegistroVentas {
    void registrarVenta(Venta venta);
    List<Venta> getVentas();
    void mostrar(Stage stage);
}