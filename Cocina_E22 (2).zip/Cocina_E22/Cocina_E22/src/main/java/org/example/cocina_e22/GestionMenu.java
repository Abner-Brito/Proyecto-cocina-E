package org.example.cocina_e22;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public class GestionMenu {
    private ObservableList<Plato> desayunoMenu = FXCollections.observableArrayList();
    private ObservableList<Plato> almuerzoMenu = FXCollections.observableArrayList();
    private ObservableList<Plato> cenaMenu = FXCollections.observableArrayList();
    private List<Ingrediente> ingredientes;

    public GestionMenu(List<Ingrediente> ingredientes) {
        this.ingredientes = ingredientes;
        // Add some initial dishes to the menus for testing
        desayunoMenu.add(new Plato("Huevos Revueltos", "Huevos con jamón y queso", 5.0, new ArrayList<>()));
        desayunoMenu.add(new Plato("Pancakes", "Pancakes con miel", 4.0, new ArrayList<>()));
        desayunoMenu.add(new Plato("Tostadas", "Tostadas con mantequilla y mermelada", 3.0, new ArrayList<>()));

        almuerzoMenu.add(new Plato("Pollo Asado", "Pollo asado con papas", 10.0, new ArrayList<>()));
        almuerzoMenu.add(new Plato("Ensalada César", "Ensalada con pollo, lechuga y aderezo César", 8.0, new ArrayList<>()));
        almuerzoMenu.add(new Plato("Sopa de Verduras", "Sopa con variedad de verduras", 9.0, new ArrayList<>()));

        cenaMenu.add(new Plato("Hamburguesa", "Hamburguesa con queso y papas fritas", 44.0, new ArrayList<>()));
        cenaMenu.add(new Plato("Pasta Alfredo", "Pasta con salsa Alfredo y pollo", 11.0, new ArrayList<>()));
        cenaMenu.add(new Plato("Tacos", "Tacos de carne con guacamole", 8.0, new ArrayList<>()));
    }

    public void mostrar(Stage stage) {
        VBox vbox = new VBox();
        Label label = new Label("Gestión de Menú");
        ListView<Plato> listView = new ListView<>(desayunoMenu); // Default to breakfast menu
        ComboBox<String> comboBox = new ComboBox<>();
        comboBox.getItems().addAll("Desayuno", "Almuerzo", "Cena");
        comboBox.setValue("Desayuno");
        comboBox.setOnAction(e -> {
            switch (comboBox.getValue()) {
                case "Desayuno":
                    listView.setItems(desayunoMenu);
                    break;
                case "Almuerzo":
                    listView.setItems(almuerzoMenu);
                    break;
                case "Cena":
                    listView.setItems(cenaMenu);
                    break;
            }
        });

        Button btnAdd = new Button("Añadir Plato");
        btnAdd.setOnAction(e -> anadirPlato(comboBox.getValue()));

        vbox.getChildren().addAll(label, comboBox, listView, btnAdd);

        Scene scene = new Scene(vbox, 400, 300);
        stage.setScene(scene);
        stage.setTitle("Gestión de Menú");
        stage.show();
    }

    private void anadirPlato(String tipoMenu) {
        Stage addStage = new Stage();
        VBox vbox = new VBox();
        Label label = new Label("Añadir Plato");
        TextField nombreField = new TextField();
        nombreField.setPromptText("Nombre del Plato");
        TextField descripcionField = new TextField();
        descripcionField.setPromptText("Descripción");
        TextField precioField = new TextField();
        precioField.setPromptText("Precio");

        Button btnSave = new Button("Guardar");
        btnSave.setOnAction(e -> {
            String nombre = nombreField.getText();
            String descripcion = descripcionField.getText();
            double precio = Double.parseDouble(precioField.getText());
            List<Ingrediente> ingredientesPlato = new ArrayList<>(); // Add logic to select ingredients
            Plato plato = new Plato(nombre, descripcion, precio, ingredientesPlato);
            switch (tipoMenu) {
                case "Desayuno":
                    desayunoMenu.add(plato);
                    break;
                case "Almuerzo":
                    almuerzoMenu.add(plato);
                    break;
                case "Cena":
                    cenaMenu.add(plato);
                    break;
            }
            addStage.close();
        });

        vbox.getChildren().addAll(label, nombreField, descripcionField, precioField, btnSave);
        Scene scene = new Scene(vbox, 300, 200);
        addStage.setScene(scene);
        addStage.setTitle("Añadir Plato");
        addStage.show();
    }

    public List<Plato> getPlatos() {
        List<Plato> allPlatos = new ArrayList<>();
        allPlatos.addAll(desayunoMenu);
        allPlatos.addAll(almuerzoMenu);
        allPlatos.addAll(cenaMenu);
        return allPlatos;
    }

    public void actualizarMenuSegunDisponibilidad() {
        // Logic to update menu based on ingredient availability
    }
}