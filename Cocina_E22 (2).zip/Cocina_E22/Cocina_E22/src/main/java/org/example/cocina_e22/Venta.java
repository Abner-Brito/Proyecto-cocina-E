package org.example.cocina_e22;

import java.time.LocalDate;
import java.util.List;

public class Venta {
    private LocalDate fecha;
    private List<Plato> platosVendidos;
    private double total;

    public Venta(LocalDate fecha, List<Plato> platosVendidos, double total) {
        this.fecha = fecha;
        this.platosVendidos = platosVendidos;
        this.total = total;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public List<Plato> getPlatos() {
        return platosVendidos;
    }

    public double getTotal() {
        return total;
    }

    @Override
    public String toString() {
        return "Venta{" +
                "fecha=" + fecha +
                ", platosVendidos=" + platosVendidos +
                ", total=" + total +
                '}';
    }
}