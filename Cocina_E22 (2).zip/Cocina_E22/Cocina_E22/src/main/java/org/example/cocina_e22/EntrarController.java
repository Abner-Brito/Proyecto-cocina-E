package org.example.cocina_e22;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class EntrarController {

    @FXML
    private ImageView logoImageView;

    @FXML
    private Button entrarButton;

    private CocinaEconomicaApp app;

    @FXML
    public void initialize() {
        // Cargar la imagen del logo
        try {
            Image logoImage = new Image(getClass().getResourceAsStream("/org/example/cocina_e22/logo.png"));
            logoImageView.setImage(logoImage);
        } catch (NullPointerException e) {
            e.printStackTrace();
            System.out.println("Imagen del logo no encontrada. Por favor, verifica la ruta.");
        }
    }

    public void setApp(CocinaEconomicaApp app) {
        this.app = app;
    }

    @FXML
    private void onEntrarButtonClick() {
        Stage stage = (Stage) entrarButton.getScene().getWindow();
        app.showMainMenu(stage);
    }
}