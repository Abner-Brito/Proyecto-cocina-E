package org.example.cocina_e22;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class RegistroVentasImpl implements RegistroVentas {
    private List<Venta> ventas;
    private ObservableList<String> ventasObservableList = FXCollections.observableArrayList();

    public RegistroVentasImpl() {
        this.ventas = new ArrayList<>();
    }

    @Override
    public void registrarVenta(Venta venta) {
        if (venta != null) {
            ventas.add(venta);
            ventasObservableList.add(venta.toString());
            guardarVentas();
        } else {
            System.err.println("Error: Venta es null y no se puede registrar.");
        }
    }

    private void guardarVentas() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("ventas.txt"))) {
            for (Venta venta : ventas) {
                if (venta != null) {
                    writer.write(venta.toString() + "\n");
                } else {
                    System.err.println("Error: Venta es null y no se puede guardar.");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Venta> getVentas() {
        return ventas;
    }

    @Override
    public void mostrar(Stage stage) {
        VBox vbox = new VBox();
        ListView<String> listView = new ListView<>(ventasObservableList);
        vbox.getChildren().add(listView);

        Scene scene = new Scene(vbox, 400, 300);
        stage.setScene(scene);
        stage.setTitle("Registro de Ventas");
        stage.show();
    }
}