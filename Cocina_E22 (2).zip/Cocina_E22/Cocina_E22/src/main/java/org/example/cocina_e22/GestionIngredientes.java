package org.example.cocina_e22;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public class GestionIngredientes {
    private ObservableList<Ingrediente> ingredientes = FXCollections.observableArrayList();
    private static final int LOW_STOCK_THRESHOLD = 5;

    public GestionIngredientes() {
        // Initialize with all ingredients for the dishes
        ingredientes.add(new Ingrediente("Huevos", 15));
        ingredientes.add(new Ingrediente("Jamón", 15));
        ingredientes.add(new Ingrediente("Queso", 15));
        ingredientes.add(new Ingrediente("Pancakes", 15));
        ingredientes.add(new Ingrediente("Miel", 15));
        ingredientes.add(new Ingrediente("Tostadas", 15));
        ingredientes.add(new Ingrediente("Mantequilla", 15));
        ingredientes.add(new Ingrediente("Mermelada", 15));
        ingredientes.add(new Ingrediente("Pollo", 15));
        ingredientes.add(new Ingrediente("Papas", 15));
        ingredientes.add(new Ingrediente("Lechuga", 15));
        ingredientes.add(new Ingrediente("Aderezo César", 15));
        ingredientes.add(new Ingrediente("Carne de Hamburguesa", 15));
        ingredientes.add(new Ingrediente("Pan de Hamburguesa", 15));
        ingredientes.add(new Ingrediente("Papas Fritas", 15));
        ingredientes.add(new Ingrediente("Verduras", 15));
        ingredientes.add(new Ingrediente("Salsa Alfredo", 15));
        ingredientes.add(new Ingrediente("Tortilla", 15));
        ingredientes.add(new Ingrediente("Guacamole", 15));
    }

    public void mostrar(Stage stage) {
        VBox vbox = new VBox();
        Label label = new Label("Gestión de Ingredientes y Stock");
        ListView<Ingrediente> listView = new ListView<>(ingredientes);
        Button btnAdd = new Button("Añadir Ingrediente");
        Button btnUpdate = new Button("Actualizar Stock");
        btnAdd.setOnAction(e -> anadirIngrediente());
        btnUpdate.setOnAction(e -> actualizarStock(listView.getSelectionModel().getSelectedItem()));

        vbox.getChildren().addAll(label, listView, btnAdd, btnUpdate);

        Scene scene = new Scene(vbox, 400, 300);
        stage.setScene(scene);
        stage.setTitle("Gestión de Ingredientes y Stock");
        stage.show();
    }

    private void anadirIngrediente() {
        Stage addStage = new Stage();
        VBox vbox = new VBox();
        Label label = new Label("Añadir Ingrediente");
        TextField nombreField = new TextField();
        nombreField.setPromptText("Nombre del Ingrediente");
        TextField cantidadField = new TextField();
        cantidadField.setPromptText("Cantidad");

        Button btnSave = new Button("Guardar");
        btnSave.setOnAction(e -> {
            String nombre = nombreField.getText();
            int cantidad = Integer.parseInt(cantidadField.getText());
            if (nombre != null && !nombre.isEmpty() && cantidad > 0) {
                ingredientes.add(new Ingrediente(nombre, cantidad));
                addStage.close();
            }
        });

        vbox.getChildren().addAll(label, nombreField, cantidadField, btnSave);
        Scene scene = new Scene(vbox, 300, 200);
        addStage.setScene(scene);
        addStage.setTitle("Añadir Ingrediente");
        addStage.show();
    }

    private void actualizarStock(Ingrediente ingrediente) {
        if (ingrediente != null) {
            Stage updateStage = new Stage();
            VBox vbox = new VBox();
            Label label = new Label("Actualizar Stock de " + ingrediente.getNombre());
            TextField cantidadField = new TextField();
            cantidadField.setPromptText("Nueva Cantidad");

            Button btnSave = new Button("Guardar");
            btnSave.setOnAction(e -> {
                int nuevaCantidad = Integer.parseInt(cantidadField.getText());
                if (nuevaCantidad >= 0) {
                    ingrediente.setCantidad(nuevaCantidad);
                    verificarStockBajo(ingrediente);
                    updateStage.close();
                }
            });

            vbox.getChildren().addAll(label, cantidadField, btnSave);
            Scene scene = new Scene(vbox, 300, 200);
            updateStage.setScene(scene);
            updateStage.setTitle("Actualizar Stock");
            updateStage.show();
        }
    }

    private void verificarStockBajo(Ingrediente ingrediente) {
        if (ingrediente.getCantidad() < LOW_STOCK_THRESHOLD) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Alerta de Stock Bajo");
            alert.setHeaderText(null);
            alert.setContentText("El stock de " + ingrediente.getNombre() + " es bajo: " + ingrediente.getCantidad() + " unidades.");
            alert.showAndWait();
        }
    }

    public List<Ingrediente> getIngredientes() {
        return new ArrayList<>(ingredientes);
    }
}