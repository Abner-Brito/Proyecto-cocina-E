package org.example.cocina_e22;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.*;
import java.util.List;

public class GestionClientes {
    private ObservableList<Cliente> clientesObservableList = FXCollections.observableArrayList();
    private static final String FILE_PATH = "clientes.txt";

    public GestionClientes() {
        cargarClientes();
    }

    public void mostrar(Stage stage) {
        VBox vbox = new VBox();
        Label label = new Label("Gestión de Clientes");
        ListView<Cliente> listView = new ListView<>(clientesObservableList);
        Button btnAdd = new Button("Añadir Cliente");
        Button btnDelete = new Button("Eliminar Cliente");
        btnAdd.setOnAction(e -> anadirCliente());
        btnDelete.setOnAction(e -> eliminarCliente(listView.getSelectionModel().getSelectedItem()));

        vbox.getChildren().addAll(label, listView, btnAdd, btnDelete);

        Scene scene = new Scene(vbox, 400, 300);
        stage.setScene(scene);
        stage.setTitle("Gestión de Clientes");
        stage.show();
    }

    private void anadirCliente() {
        Stage addStage = new Stage();
        VBox vbox = new VBox();
        Label label = new Label("Añadir Cliente");
        TextField nombreField = new TextField();
        nombreField.setPromptText("Nombre");
        TextField contactoField = new TextField();
        contactoField.setPromptText("Información de Contacto");
        TextField preferenciasField = new TextField();
        preferenciasField.setPromptText("Preferencias");
        Button btnSave = new Button("Guardar");
        btnSave.setOnAction(e -> {
            String nombre = nombreField.getText();
            String contacto = contactoField.getText();
            String preferencias = preferenciasField.getText();
            if (!nombre.isEmpty() && !contacto.isEmpty() && !preferencias.isEmpty()) {
                Cliente cliente = new Cliente(nombre, contacto, preferencias);
                clientesObservableList.add(cliente);
                guardarClientes();
                addStage.close();
            }
        });

        vbox.getChildren().addAll(label, nombreField, contactoField, preferenciasField, btnSave);
        Scene scene = new Scene(vbox, 300, 200);
        addStage.setScene(scene);
        addStage.setTitle("Añadir Cliente");
        addStage.show();
    }

    private void eliminarCliente(Cliente cliente) {
        if (cliente != null) {
            clientesObservableList.remove(cliente);
            guardarClientes();
        }
    }

    private void guardarClientes() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (Cliente cliente : clientesObservableList) {
                writer.write(cliente.toString());
                writer.newLine();
            }
            System.out.println("Clientes guardados correctamente.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void cargarClientes() {
        File file = new File(FILE_PATH);
        if (file.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                clientesObservableList.clear();
                while ((line = reader.readLine()) != null) {
                    clientesObservableList.add(Cliente.fromString(line));
                }
                System.out.println("Clientes cargados correctamente.");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}